interface IProductCategory {  
    _id?: string;
  
    categoryName : ;
  
    categoryCode : ;
 
}

export class ProductCategory {
    _id?: string;
  
	categoryName : ;
  
	categoryCode : ;
 

    constructor(obj?: IProductCategory) {
    }
}