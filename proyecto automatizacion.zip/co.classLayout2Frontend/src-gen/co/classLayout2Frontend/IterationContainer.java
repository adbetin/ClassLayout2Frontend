/**
 */
package co.classLayout2Frontend;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Iteration Container</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.IterationContainer#getIterationFilters <em>Iteration Filters</em>}</li>
 * </ul>
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getIterationContainer()
 * @model
 * @generated
 */
public interface IterationContainer extends ContainerView {
	/**
	 * Returns the value of the '<em><b>Iteration Filters</b></em>' containment reference list.
	 * The list contents are of type {@link co.classLayout2Frontend.IterationFilter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Iteration Filters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Iteration Filters</em>' containment reference list.
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getIterationContainer_IterationFilters()
	 * @model containment="true"
	 * @generated
	 */
	EList<IterationFilter> getIterationFilters();

} // IterationContainer
