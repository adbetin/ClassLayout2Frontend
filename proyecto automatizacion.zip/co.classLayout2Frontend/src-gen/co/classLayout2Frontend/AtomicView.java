/**
 */
package co.classLayout2Frontend;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Atomic View</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.AtomicView#getProperty <em>Property</em>}</li>
 * </ul>
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getAtomicView()
 * @model abstract="true"
 * @generated
 */
public interface AtomicView extends ElementView {
	/**
	 * Returns the value of the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Property</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Property</em>' reference.
	 * @see #setProperty(StructuralFeature)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getAtomicView_Property()
	 * @model
	 * @generated
	 */
	StructuralFeature getProperty();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.AtomicView#getProperty <em>Property</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Property</em>' reference.
	 * @see #getProperty()
	 * @generated
	 */
	void setProperty(StructuralFeature value);

} // AtomicView
