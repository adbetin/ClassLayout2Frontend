/**
 */
package co.classLayout2Frontend;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Text</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.InputText#isMultiline <em>Multiline</em>}</li>
 * </ul>
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getInputText()
 * @model
 * @generated
 */
public interface InputText extends Input {
	/**
	 * Returns the value of the '<em><b>Multiline</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Multiline</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multiline</em>' attribute.
	 * @see #setMultiline(boolean)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getInputText_Multiline()
	 * @model
	 * @generated
	 */
	boolean isMultiline();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.InputText#isMultiline <em>Multiline</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multiline</em>' attribute.
	 * @see #isMultiline()
	 * @generated
	 */
	void setMultiline(boolean value);

} // InputText
