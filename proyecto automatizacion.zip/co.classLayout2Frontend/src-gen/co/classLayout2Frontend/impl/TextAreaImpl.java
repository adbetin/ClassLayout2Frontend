/**
 */
package co.classLayout2Frontend.impl;

import co.classLayout2Frontend.ClassLayout2FrontendPackage;
import co.classLayout2Frontend.TextArea;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Text Area</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.impl.TextAreaImpl#getValue <em>Value</em>}</li>
 *   <li>{@link co.classLayout2Frontend.impl.TextAreaImpl#isIsTitle <em>Is Title</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TextAreaImpl extends OutputImpl implements TextArea {
	/**
	 * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected static final String VALUE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected String value = VALUE_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsTitle() <em>Is Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsTitle()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_TITLE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsTitle() <em>Is Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsTitle()
	 * @generated
	 * @ordered
	 */
	protected boolean isTitle = IS_TITLE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TextAreaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassLayout2FrontendPackage.Literals.TEXT_AREA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(String newValue) {
		String oldValue = value;
		value = newValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassLayout2FrontendPackage.TEXT_AREA__VALUE,
					oldValue, value));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsTitle() {
		return isTitle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsTitle(boolean newIsTitle) {
		boolean oldIsTitle = isTitle;
		isTitle = newIsTitle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassLayout2FrontendPackage.TEXT_AREA__IS_TITLE,
					oldIsTitle, isTitle));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.TEXT_AREA__VALUE:
			return getValue();
		case ClassLayout2FrontendPackage.TEXT_AREA__IS_TITLE:
			return isIsTitle();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.TEXT_AREA__VALUE:
			setValue((String) newValue);
			return;
		case ClassLayout2FrontendPackage.TEXT_AREA__IS_TITLE:
			setIsTitle((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.TEXT_AREA__VALUE:
			setValue(VALUE_EDEFAULT);
			return;
		case ClassLayout2FrontendPackage.TEXT_AREA__IS_TITLE:
			setIsTitle(IS_TITLE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.TEXT_AREA__VALUE:
			return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
		case ClassLayout2FrontendPackage.TEXT_AREA__IS_TITLE:
			return isTitle != IS_TITLE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (value: ");
		result.append(value);
		result.append(", isTitle: ");
		result.append(isTitle);
		result.append(')');
		return result.toString();
	}

} //TextAreaImpl
