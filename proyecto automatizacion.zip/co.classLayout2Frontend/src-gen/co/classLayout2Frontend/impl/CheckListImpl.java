/**
 */
package co.classLayout2Frontend.impl;

import co.classLayout2Frontend.CheckList;
import co.classLayout2Frontend.ClassLayout2FrontendPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Check List</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CheckListImpl extends SelectionImpl implements CheckList {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CheckListImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassLayout2FrontendPackage.Literals.CHECK_LIST;
	}

} //CheckListImpl
