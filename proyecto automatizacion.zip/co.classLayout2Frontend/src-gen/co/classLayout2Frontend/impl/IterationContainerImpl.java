/**
 */
package co.classLayout2Frontend.impl;

import co.classLayout2Frontend.ClassLayout2FrontendPackage;
import co.classLayout2Frontend.IterationContainer;
import co.classLayout2Frontend.IterationFilter;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Iteration Container</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.impl.IterationContainerImpl#getIterationFilters <em>Iteration Filters</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IterationContainerImpl extends ContainerViewImpl implements IterationContainer {
	/**
	 * The cached value of the '{@link #getIterationFilters() <em>Iteration Filters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIterationFilters()
	 * @generated
	 * @ordered
	 */
	protected EList<IterationFilter> iterationFilters;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IterationContainerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassLayout2FrontendPackage.Literals.ITERATION_CONTAINER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<IterationFilter> getIterationFilters() {
		if (iterationFilters == null) {
			iterationFilters = new EObjectContainmentEList<IterationFilter>(IterationFilter.class, this,
					ClassLayout2FrontendPackage.ITERATION_CONTAINER__ITERATION_FILTERS);
		}
		return iterationFilters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.ITERATION_CONTAINER__ITERATION_FILTERS:
			return ((InternalEList<?>) getIterationFilters()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.ITERATION_CONTAINER__ITERATION_FILTERS:
			return getIterationFilters();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.ITERATION_CONTAINER__ITERATION_FILTERS:
			getIterationFilters().clear();
			getIterationFilters().addAll((Collection<? extends IterationFilter>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.ITERATION_CONTAINER__ITERATION_FILTERS:
			getIterationFilters().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.ITERATION_CONTAINER__ITERATION_FILTERS:
			return iterationFilters != null && !iterationFilters.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //IterationContainerImpl
