/**
 */
package co.classLayout2Frontend.impl;

import co.classLayout2Frontend.ClassLayout2FrontendPackage;
import co.classLayout2Frontend.PrimitiveType;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Primitive Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PrimitiveTypeImpl extends PropertyTypeImpl implements PrimitiveType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PrimitiveTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassLayout2FrontendPackage.Literals.PRIMITIVE_TYPE;
	}

} //PrimitiveTypeImpl
