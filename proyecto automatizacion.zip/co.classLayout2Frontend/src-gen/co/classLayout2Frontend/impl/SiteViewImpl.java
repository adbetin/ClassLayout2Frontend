/**
 */
package co.classLayout2Frontend.impl;

import co.classLayout2Frontend.ClassLayout2FrontendPackage;
import co.classLayout2Frontend.PageView;
import co.classLayout2Frontend.SiteView;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Site View</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.impl.SiteViewImpl#getName <em>Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.impl.SiteViewImpl#getTemplateName <em>Template Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.impl.SiteViewImpl#getTemplateColor <em>Template Color</em>}</li>
 *   <li>{@link co.classLayout2Frontend.impl.SiteViewImpl#getDisplayName <em>Display Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.impl.SiteViewImpl#getPageViews <em>Page Views</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SiteViewImpl extends MinimalEObjectImpl.Container implements SiteView {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getTemplateName() <em>Template Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemplateName()
	 * @generated
	 * @ordered
	 */
	protected static final String TEMPLATE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTemplateName() <em>Template Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemplateName()
	 * @generated
	 * @ordered
	 */
	protected String templateName = TEMPLATE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getTemplateColor() <em>Template Color</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemplateColor()
	 * @generated
	 * @ordered
	 */
	protected static final String TEMPLATE_COLOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTemplateColor() <em>Template Color</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemplateColor()
	 * @generated
	 * @ordered
	 */
	protected String templateColor = TEMPLATE_COLOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getDisplayName() <em>Display Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDisplayName()
	 * @generated
	 * @ordered
	 */
	protected static final String DISPLAY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDisplayName() <em>Display Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDisplayName()
	 * @generated
	 * @ordered
	 */
	protected String displayName = DISPLAY_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPageViews() <em>Page Views</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPageViews()
	 * @generated
	 * @ordered
	 */
	protected EList<PageView> pageViews;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SiteViewImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassLayout2FrontendPackage.Literals.SITE_VIEW;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassLayout2FrontendPackage.SITE_VIEW__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTemplateName(String newTemplateName) {
		String oldTemplateName = templateName;
		templateName = newTemplateName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_NAME,
					oldTemplateName, templateName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTemplateColor() {
		return templateColor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTemplateColor(String newTemplateColor) {
		String oldTemplateColor = templateColor;
		templateColor = newTemplateColor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_COLOR,
					oldTemplateColor, templateColor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDisplayName(String newDisplayName) {
		String oldDisplayName = displayName;
		displayName = newDisplayName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassLayout2FrontendPackage.SITE_VIEW__DISPLAY_NAME,
					oldDisplayName, displayName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PageView> getPageViews() {
		if (pageViews == null) {
			pageViews = new EObjectResolvingEList<PageView>(PageView.class, this,
					ClassLayout2FrontendPackage.SITE_VIEW__PAGE_VIEWS);
		}
		return pageViews;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.SITE_VIEW__NAME:
			return getName();
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_NAME:
			return getTemplateName();
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_COLOR:
			return getTemplateColor();
		case ClassLayout2FrontendPackage.SITE_VIEW__DISPLAY_NAME:
			return getDisplayName();
		case ClassLayout2FrontendPackage.SITE_VIEW__PAGE_VIEWS:
			return getPageViews();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.SITE_VIEW__NAME:
			setName((String) newValue);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_NAME:
			setTemplateName((String) newValue);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_COLOR:
			setTemplateColor((String) newValue);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__DISPLAY_NAME:
			setDisplayName((String) newValue);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__PAGE_VIEWS:
			getPageViews().clear();
			getPageViews().addAll((Collection<? extends PageView>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.SITE_VIEW__NAME:
			setName(NAME_EDEFAULT);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_NAME:
			setTemplateName(TEMPLATE_NAME_EDEFAULT);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_COLOR:
			setTemplateColor(TEMPLATE_COLOR_EDEFAULT);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__DISPLAY_NAME:
			setDisplayName(DISPLAY_NAME_EDEFAULT);
			return;
		case ClassLayout2FrontendPackage.SITE_VIEW__PAGE_VIEWS:
			getPageViews().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ClassLayout2FrontendPackage.SITE_VIEW__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_NAME:
			return TEMPLATE_NAME_EDEFAULT == null ? templateName != null : !TEMPLATE_NAME_EDEFAULT.equals(templateName);
		case ClassLayout2FrontendPackage.SITE_VIEW__TEMPLATE_COLOR:
			return TEMPLATE_COLOR_EDEFAULT == null ? templateColor != null
					: !TEMPLATE_COLOR_EDEFAULT.equals(templateColor);
		case ClassLayout2FrontendPackage.SITE_VIEW__DISPLAY_NAME:
			return DISPLAY_NAME_EDEFAULT == null ? displayName != null : !DISPLAY_NAME_EDEFAULT.equals(displayName);
		case ClassLayout2FrontendPackage.SITE_VIEW__PAGE_VIEWS:
			return pageViews != null && !pageViews.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", templateName: ");
		result.append(templateName);
		result.append(", templateColor: ");
		result.append(templateColor);
		result.append(", displayName: ");
		result.append(displayName);
		result.append(')');
		return result.toString();
	}

} //SiteViewImpl
