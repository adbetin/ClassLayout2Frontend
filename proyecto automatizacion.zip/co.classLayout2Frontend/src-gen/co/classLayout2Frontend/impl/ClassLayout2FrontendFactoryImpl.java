/**
 */
package co.classLayout2Frontend.impl;

import co.classLayout2Frontend.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ClassLayout2FrontendFactoryImpl extends EFactoryImpl implements ClassLayout2FrontendFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ClassLayout2FrontendFactory init() {
		try {
			ClassLayout2FrontendFactory theClassLayout2FrontendFactory = (ClassLayout2FrontendFactory) EPackage.Registry.INSTANCE
					.getEFactory(ClassLayout2FrontendPackage.eNS_URI);
			if (theClassLayout2FrontendFactory != null) {
				return theClassLayout2FrontendFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ClassLayout2FrontendFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassLayout2FrontendFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ClassLayout2FrontendPackage.PROJECT:
			return createProject();
		case ClassLayout2FrontendPackage.COMPOSITION:
			return createComposition();
		case ClassLayout2FrontendPackage.PROPERTY:
			return createProperty();
		case ClassLayout2FrontendPackage.ENTITIES_MODEL:
			return createEntitiesModel();
		case ClassLayout2FrontendPackage.ENTITY:
			return createEntity();
		case ClassLayout2FrontendPackage.PRIMITIVE_TYPE:
			return createPrimitiveType();
		case ClassLayout2FrontendPackage.LITERAL:
			return createLiteral();
		case ClassLayout2FrontendPackage.ENUMERATION:
			return createEnumeration();
		case ClassLayout2FrontendPackage.REFERENCE:
			return createReference();
		case ClassLayout2FrontendPackage.AUTOCOMPLETE:
			return createAutocomplete();
		case ClassLayout2FrontendPackage.DROPDOWNLIST:
			return createDropdownlist();
		case ClassLayout2FrontendPackage.IMAGE:
			return createImage();
		case ClassLayout2FrontendPackage.LIST:
			return createList();
		case ClassLayout2FrontendPackage.ITERATION_FILTER:
			return createIterationFilter();
		case ClassLayout2FrontendPackage.INPUT_TEXT:
			return createInputText();
		case ClassLayout2FrontendPackage.PAGE_VIEW:
			return createPageView();
		case ClassLayout2FrontendPackage.SITE_VIEW:
			return createSiteView();
		case ClassLayout2FrontendPackage.STATIC_CONTAINER:
			return createStaticContainer();
		case ClassLayout2FrontendPackage.TEXT_AREA:
			return createTextArea();
		case ClassLayout2FrontendPackage.ITERATION_CONTAINER:
			return createIterationContainer();
		case ClassLayout2FrontendPackage.INPUT_FORM:
			return createInputForm();
		case ClassLayout2FrontendPackage.CHECK_LIST:
			return createCheckList();
		case ClassLayout2FrontendPackage.RADIO_BUTTON_GROUP:
			return createRadioButtonGroup();
		case ClassLayout2FrontendPackage.FILE_UPLOAD:
			return createFileUpload();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case ClassLayout2FrontendPackage.LAYOUT_TYPE:
			return createLayoutTypeFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case ClassLayout2FrontendPackage.LAYOUT_TYPE:
			return convertLayoutTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Project createProject() {
		ProjectImpl project = new ProjectImpl();
		return project;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Composition createComposition() {
		CompositionImpl composition = new CompositionImpl();
		return composition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Property createProperty() {
		PropertyImpl property = new PropertyImpl();
		return property;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntitiesModel createEntitiesModel() {
		EntitiesModelImpl entitiesModel = new EntitiesModelImpl();
		return entitiesModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entity createEntity() {
		EntityImpl entity = new EntityImpl();
		return entity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PrimitiveType createPrimitiveType() {
		PrimitiveTypeImpl primitiveType = new PrimitiveTypeImpl();
		return primitiveType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Literal createLiteral() {
		LiteralImpl literal = new LiteralImpl();
		return literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Enumeration createEnumeration() {
		EnumerationImpl enumeration = new EnumerationImpl();
		return enumeration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Reference createReference() {
		ReferenceImpl reference = new ReferenceImpl();
		return reference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Autocomplete createAutocomplete() {
		AutocompleteImpl autocomplete = new AutocompleteImpl();
		return autocomplete;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dropdownlist createDropdownlist() {
		DropdownlistImpl dropdownlist = new DropdownlistImpl();
		return dropdownlist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Image createImage() {
		ImageImpl image = new ImageImpl();
		return image;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List createList() {
		ListImpl list = new ListImpl();
		return list;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IterationFilter createIterationFilter() {
		IterationFilterImpl iterationFilter = new IterationFilterImpl();
		return iterationFilter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputText createInputText() {
		InputTextImpl inputText = new InputTextImpl();
		return inputText;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PageView createPageView() {
		PageViewImpl pageView = new PageViewImpl();
		return pageView;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SiteView createSiteView() {
		SiteViewImpl siteView = new SiteViewImpl();
		return siteView;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StaticContainer createStaticContainer() {
		StaticContainerImpl staticContainer = new StaticContainerImpl();
		return staticContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TextArea createTextArea() {
		TextAreaImpl textArea = new TextAreaImpl();
		return textArea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IterationContainer createIterationContainer() {
		IterationContainerImpl iterationContainer = new IterationContainerImpl();
		return iterationContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputForm createInputForm() {
		InputFormImpl inputForm = new InputFormImpl();
		return inputForm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CheckList createCheckList() {
		CheckListImpl checkList = new CheckListImpl();
		return checkList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RadioButtonGroup createRadioButtonGroup() {
		RadioButtonGroupImpl radioButtonGroup = new RadioButtonGroupImpl();
		return radioButtonGroup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FileUpload createFileUpload() {
		FileUploadImpl fileUpload = new FileUploadImpl();
		return fileUpload;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LayoutType createLayoutTypeFromString(EDataType eDataType, String initialValue) {
		LayoutType result = LayoutType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLayoutTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassLayout2FrontendPackage getClassLayout2FrontendPackage() {
		return (ClassLayout2FrontendPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ClassLayout2FrontendPackage getPackage() {
		return ClassLayout2FrontendPackage.eINSTANCE;
	}

} //ClassLayout2FrontendFactoryImpl
