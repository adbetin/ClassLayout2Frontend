/**
 */
package co.classLayout2Frontend.impl;

import co.classLayout2Frontend.ClassLayout2FrontendPackage;
import co.classLayout2Frontend.Reference;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ReferenceImpl extends AssociationImpl implements Reference {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ReferenceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassLayout2FrontendPackage.Literals.REFERENCE;
	}

} //ReferenceImpl
