/**
 */
package co.classLayout2Frontend;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dropdownlist</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getDropdownlist()
 * @model
 * @generated
 */
public interface Dropdownlist extends Selection {
} // Dropdownlist
