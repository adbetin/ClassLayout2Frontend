/**
 */
package co.classLayout2Frontend.util;

import co.classLayout2Frontend.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage
 * @generated
 */
public class ClassLayout2FrontendAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ClassLayout2FrontendPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassLayout2FrontendAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ClassLayout2FrontendPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassLayout2FrontendSwitch<Adapter> modelSwitch = new ClassLayout2FrontendSwitch<Adapter>() {
		@Override
		public Adapter caseProject(Project object) {
			return createProjectAdapter();
		}

		@Override
		public Adapter caseComposition(Composition object) {
			return createCompositionAdapter();
		}

		@Override
		public Adapter caseAssociation(Association object) {
			return createAssociationAdapter();
		}

		@Override
		public Adapter casePropertyType(PropertyType object) {
			return createPropertyTypeAdapter();
		}

		@Override
		public Adapter caseProperty(Property object) {
			return createPropertyAdapter();
		}

		@Override
		public Adapter caseStructuralFeature(StructuralFeature object) {
			return createStructuralFeatureAdapter();
		}

		@Override
		public Adapter caseEntitiesModel(EntitiesModel object) {
			return createEntitiesModelAdapter();
		}

		@Override
		public Adapter caseEntityModelElement(EntityModelElement object) {
			return createEntityModelElementAdapter();
		}

		@Override
		public Adapter caseEntity(Entity object) {
			return createEntityAdapter();
		}

		@Override
		public Adapter casePrimitiveType(PrimitiveType object) {
			return createPrimitiveTypeAdapter();
		}

		@Override
		public Adapter caseLiteral(Literal object) {
			return createLiteralAdapter();
		}

		@Override
		public Adapter caseEnumeration(Enumeration object) {
			return createEnumerationAdapter();
		}

		@Override
		public Adapter caseReference(Reference object) {
			return createReferenceAdapter();
		}

		@Override
		public Adapter caseAtomicView(AtomicView object) {
			return createAtomicViewAdapter();
		}

		@Override
		public Adapter caseAutocomplete(Autocomplete object) {
			return createAutocompleteAdapter();
		}

		@Override
		public Adapter caseDropdownlist(Dropdownlist object) {
			return createDropdownlistAdapter();
		}

		@Override
		public Adapter caseImage(Image object) {
			return createImageAdapter();
		}

		@Override
		public Adapter caseList(List object) {
			return createListAdapter();
		}

		@Override
		public Adapter caseOutput(Output object) {
			return createOutputAdapter();
		}

		@Override
		public Adapter caseIterationFilter(IterationFilter object) {
			return createIterationFilterAdapter();
		}

		@Override
		public Adapter caseInputText(InputText object) {
			return createInputTextAdapter();
		}

		@Override
		public Adapter casePageView(PageView object) {
			return createPageViewAdapter();
		}

		@Override
		public Adapter caseSiteView(SiteView object) {
			return createSiteViewAdapter();
		}

		@Override
		public Adapter caseStaticContainer(StaticContainer object) {
			return createStaticContainerAdapter();
		}

		@Override
		public Adapter caseTextArea(TextArea object) {
			return createTextAreaAdapter();
		}

		@Override
		public Adapter caseSelection(Selection object) {
			return createSelectionAdapter();
		}

		@Override
		public Adapter caseInput(Input object) {
			return createInputAdapter();
		}

		@Override
		public Adapter caseIterationContainer(IterationContainer object) {
			return createIterationContainerAdapter();
		}

		@Override
		public Adapter caseInputForm(InputForm object) {
			return createInputFormAdapter();
		}

		@Override
		public Adapter caseCheckList(CheckList object) {
			return createCheckListAdapter();
		}

		@Override
		public Adapter caseElementView(ElementView object) {
			return createElementViewAdapter();
		}

		@Override
		public Adapter caseRadioButtonGroup(RadioButtonGroup object) {
			return createRadioButtonGroupAdapter();
		}

		@Override
		public Adapter caseContainerView(ContainerView object) {
			return createContainerViewAdapter();
		}

		@Override
		public Adapter caseFileUpload(FileUpload object) {
			return createFileUploadAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Project <em>Project</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Project
	 * @generated
	 */
	public Adapter createProjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Composition <em>Composition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Composition
	 * @generated
	 */
	public Adapter createCompositionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Association <em>Association</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Association
	 * @generated
	 */
	public Adapter createAssociationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.PropertyType <em>Property Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.PropertyType
	 * @generated
	 */
	public Adapter createPropertyTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Property <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Property
	 * @generated
	 */
	public Adapter createPropertyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.StructuralFeature <em>Structural Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.StructuralFeature
	 * @generated
	 */
	public Adapter createStructuralFeatureAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.EntitiesModel <em>Entities Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.EntitiesModel
	 * @generated
	 */
	public Adapter createEntitiesModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.EntityModelElement <em>Entity Model Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.EntityModelElement
	 * @generated
	 */
	public Adapter createEntityModelElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Entity <em>Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Entity
	 * @generated
	 */
	public Adapter createEntityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.PrimitiveType <em>Primitive Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.PrimitiveType
	 * @generated
	 */
	public Adapter createPrimitiveTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Literal <em>Literal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Literal
	 * @generated
	 */
	public Adapter createLiteralAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Enumeration <em>Enumeration</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Enumeration
	 * @generated
	 */
	public Adapter createEnumerationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Reference <em>Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Reference
	 * @generated
	 */
	public Adapter createReferenceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.AtomicView <em>Atomic View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.AtomicView
	 * @generated
	 */
	public Adapter createAtomicViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Autocomplete <em>Autocomplete</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Autocomplete
	 * @generated
	 */
	public Adapter createAutocompleteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Dropdownlist <em>Dropdownlist</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Dropdownlist
	 * @generated
	 */
	public Adapter createDropdownlistAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Image <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Image
	 * @generated
	 */
	public Adapter createImageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.List
	 * @generated
	 */
	public Adapter createListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Output <em>Output</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Output
	 * @generated
	 */
	public Adapter createOutputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.IterationFilter <em>Iteration Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.IterationFilter
	 * @generated
	 */
	public Adapter createIterationFilterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.InputText <em>Input Text</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.InputText
	 * @generated
	 */
	public Adapter createInputTextAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.PageView <em>Page View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.PageView
	 * @generated
	 */
	public Adapter createPageViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.SiteView <em>Site View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.SiteView
	 * @generated
	 */
	public Adapter createSiteViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.StaticContainer <em>Static Container</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.StaticContainer
	 * @generated
	 */
	public Adapter createStaticContainerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.TextArea <em>Text Area</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.TextArea
	 * @generated
	 */
	public Adapter createTextAreaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Selection <em>Selection</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Selection
	 * @generated
	 */
	public Adapter createSelectionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.Input <em>Input</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.Input
	 * @generated
	 */
	public Adapter createInputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.IterationContainer <em>Iteration Container</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.IterationContainer
	 * @generated
	 */
	public Adapter createIterationContainerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.InputForm <em>Input Form</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.InputForm
	 * @generated
	 */
	public Adapter createInputFormAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.CheckList <em>Check List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.CheckList
	 * @generated
	 */
	public Adapter createCheckListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.ElementView <em>Element View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.ElementView
	 * @generated
	 */
	public Adapter createElementViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.RadioButtonGroup <em>Radio Button Group</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.RadioButtonGroup
	 * @generated
	 */
	public Adapter createRadioButtonGroupAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.ContainerView <em>Container View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.ContainerView
	 * @generated
	 */
	public Adapter createContainerViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link co.classLayout2Frontend.FileUpload <em>File Upload</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see co.classLayout2Frontend.FileUpload
	 * @generated
	 */
	public Adapter createFileUploadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //ClassLayout2FrontendAdapterFactory
