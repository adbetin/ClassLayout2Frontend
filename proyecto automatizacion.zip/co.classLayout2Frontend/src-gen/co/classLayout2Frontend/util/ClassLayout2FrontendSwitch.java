/**
 */
package co.classLayout2Frontend.util;

import co.classLayout2Frontend.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage
 * @generated
 */
public class ClassLayout2FrontendSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ClassLayout2FrontendPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassLayout2FrontendSwitch() {
		if (modelPackage == null) {
			modelPackage = ClassLayout2FrontendPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case ClassLayout2FrontendPackage.PROJECT: {
			Project project = (Project) theEObject;
			T result = caseProject(project);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.COMPOSITION: {
			Composition composition = (Composition) theEObject;
			T result = caseComposition(composition);
			if (result == null)
				result = caseAssociation(composition);
			if (result == null)
				result = caseStructuralFeature(composition);
			if (result == null)
				result = caseEntityModelElement(composition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ASSOCIATION: {
			Association association = (Association) theEObject;
			T result = caseAssociation(association);
			if (result == null)
				result = caseStructuralFeature(association);
			if (result == null)
				result = caseEntityModelElement(association);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.PROPERTY_TYPE: {
			PropertyType propertyType = (PropertyType) theEObject;
			T result = casePropertyType(propertyType);
			if (result == null)
				result = caseEntityModelElement(propertyType);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.PROPERTY: {
			Property property = (Property) theEObject;
			T result = caseProperty(property);
			if (result == null)
				result = caseStructuralFeature(property);
			if (result == null)
				result = caseEntityModelElement(property);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.STRUCTURAL_FEATURE: {
			StructuralFeature structuralFeature = (StructuralFeature) theEObject;
			T result = caseStructuralFeature(structuralFeature);
			if (result == null)
				result = caseEntityModelElement(structuralFeature);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ENTITIES_MODEL: {
			EntitiesModel entitiesModel = (EntitiesModel) theEObject;
			T result = caseEntitiesModel(entitiesModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ENTITY_MODEL_ELEMENT: {
			EntityModelElement entityModelElement = (EntityModelElement) theEObject;
			T result = caseEntityModelElement(entityModelElement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ENTITY: {
			Entity entity = (Entity) theEObject;
			T result = caseEntity(entity);
			if (result == null)
				result = caseEntityModelElement(entity);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.PRIMITIVE_TYPE: {
			PrimitiveType primitiveType = (PrimitiveType) theEObject;
			T result = casePrimitiveType(primitiveType);
			if (result == null)
				result = casePropertyType(primitiveType);
			if (result == null)
				result = caseEntityModelElement(primitiveType);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.LITERAL: {
			Literal literal = (Literal) theEObject;
			T result = caseLiteral(literal);
			if (result == null)
				result = caseEntityModelElement(literal);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ENUMERATION: {
			Enumeration enumeration = (Enumeration) theEObject;
			T result = caseEnumeration(enumeration);
			if (result == null)
				result = casePropertyType(enumeration);
			if (result == null)
				result = caseEntityModelElement(enumeration);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.REFERENCE: {
			Reference reference = (Reference) theEObject;
			T result = caseReference(reference);
			if (result == null)
				result = caseAssociation(reference);
			if (result == null)
				result = caseStructuralFeature(reference);
			if (result == null)
				result = caseEntityModelElement(reference);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ATOMIC_VIEW: {
			AtomicView atomicView = (AtomicView) theEObject;
			T result = caseAtomicView(atomicView);
			if (result == null)
				result = caseElementView(atomicView);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.AUTOCOMPLETE: {
			Autocomplete autocomplete = (Autocomplete) theEObject;
			T result = caseAutocomplete(autocomplete);
			if (result == null)
				result = caseSelection(autocomplete);
			if (result == null)
				result = caseInput(autocomplete);
			if (result == null)
				result = caseAtomicView(autocomplete);
			if (result == null)
				result = caseElementView(autocomplete);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.DROPDOWNLIST: {
			Dropdownlist dropdownlist = (Dropdownlist) theEObject;
			T result = caseDropdownlist(dropdownlist);
			if (result == null)
				result = caseSelection(dropdownlist);
			if (result == null)
				result = caseInput(dropdownlist);
			if (result == null)
				result = caseAtomicView(dropdownlist);
			if (result == null)
				result = caseElementView(dropdownlist);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.IMAGE: {
			Image image = (Image) theEObject;
			T result = caseImage(image);
			if (result == null)
				result = caseOutput(image);
			if (result == null)
				result = caseAtomicView(image);
			if (result == null)
				result = caseElementView(image);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.LIST: {
			List list = (List) theEObject;
			T result = caseList(list);
			if (result == null)
				result = caseSelection(list);
			if (result == null)
				result = caseInput(list);
			if (result == null)
				result = caseAtomicView(list);
			if (result == null)
				result = caseElementView(list);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.OUTPUT: {
			Output output = (Output) theEObject;
			T result = caseOutput(output);
			if (result == null)
				result = caseAtomicView(output);
			if (result == null)
				result = caseElementView(output);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ITERATION_FILTER: {
			IterationFilter iterationFilter = (IterationFilter) theEObject;
			T result = caseIterationFilter(iterationFilter);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.INPUT_TEXT: {
			InputText inputText = (InputText) theEObject;
			T result = caseInputText(inputText);
			if (result == null)
				result = caseInput(inputText);
			if (result == null)
				result = caseAtomicView(inputText);
			if (result == null)
				result = caseElementView(inputText);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.PAGE_VIEW: {
			PageView pageView = (PageView) theEObject;
			T result = casePageView(pageView);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.SITE_VIEW: {
			SiteView siteView = (SiteView) theEObject;
			T result = caseSiteView(siteView);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.STATIC_CONTAINER: {
			StaticContainer staticContainer = (StaticContainer) theEObject;
			T result = caseStaticContainer(staticContainer);
			if (result == null)
				result = caseContainerView(staticContainer);
			if (result == null)
				result = caseElementView(staticContainer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.TEXT_AREA: {
			TextArea textArea = (TextArea) theEObject;
			T result = caseTextArea(textArea);
			if (result == null)
				result = caseOutput(textArea);
			if (result == null)
				result = caseAtomicView(textArea);
			if (result == null)
				result = caseElementView(textArea);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.SELECTION: {
			Selection selection = (Selection) theEObject;
			T result = caseSelection(selection);
			if (result == null)
				result = caseInput(selection);
			if (result == null)
				result = caseAtomicView(selection);
			if (result == null)
				result = caseElementView(selection);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.INPUT: {
			Input input = (Input) theEObject;
			T result = caseInput(input);
			if (result == null)
				result = caseAtomicView(input);
			if (result == null)
				result = caseElementView(input);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ITERATION_CONTAINER: {
			IterationContainer iterationContainer = (IterationContainer) theEObject;
			T result = caseIterationContainer(iterationContainer);
			if (result == null)
				result = caseContainerView(iterationContainer);
			if (result == null)
				result = caseElementView(iterationContainer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.INPUT_FORM: {
			InputForm inputForm = (InputForm) theEObject;
			T result = caseInputForm(inputForm);
			if (result == null)
				result = caseContainerView(inputForm);
			if (result == null)
				result = caseElementView(inputForm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.CHECK_LIST: {
			CheckList checkList = (CheckList) theEObject;
			T result = caseCheckList(checkList);
			if (result == null)
				result = caseSelection(checkList);
			if (result == null)
				result = caseInput(checkList);
			if (result == null)
				result = caseAtomicView(checkList);
			if (result == null)
				result = caseElementView(checkList);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.ELEMENT_VIEW: {
			ElementView elementView = (ElementView) theEObject;
			T result = caseElementView(elementView);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.RADIO_BUTTON_GROUP: {
			RadioButtonGroup radioButtonGroup = (RadioButtonGroup) theEObject;
			T result = caseRadioButtonGroup(radioButtonGroup);
			if (result == null)
				result = caseSelection(radioButtonGroup);
			if (result == null)
				result = caseInput(radioButtonGroup);
			if (result == null)
				result = caseAtomicView(radioButtonGroup);
			if (result == null)
				result = caseElementView(radioButtonGroup);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.CONTAINER_VIEW: {
			ContainerView containerView = (ContainerView) theEObject;
			T result = caseContainerView(containerView);
			if (result == null)
				result = caseElementView(containerView);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ClassLayout2FrontendPackage.FILE_UPLOAD: {
			FileUpload fileUpload = (FileUpload) theEObject;
			T result = caseFileUpload(fileUpload);
			if (result == null)
				result = caseInput(fileUpload);
			if (result == null)
				result = caseAtomicView(fileUpload);
			if (result == null)
				result = caseElementView(fileUpload);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Project</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Project</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseProject(Project object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Composition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Composition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseComposition(Composition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Association</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Association</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAssociation(Association object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Property Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Property Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePropertyType(PropertyType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Property</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Property</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseProperty(Property object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Structural Feature</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Structural Feature</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStructuralFeature(StructuralFeature object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Entities Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Entities Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEntitiesModel(EntitiesModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Entity Model Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Entity Model Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEntityModelElement(EntityModelElement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Entity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Entity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEntity(Entity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Primitive Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Primitive Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePrimitiveType(PrimitiveType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Literal</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Literal</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLiteral(Literal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Enumeration</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Enumeration</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnumeration(Enumeration object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Reference</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Reference</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReference(Reference object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Atomic View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Atomic View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAtomicView(AtomicView object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Autocomplete</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Autocomplete</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAutocomplete(Autocomplete object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dropdownlist</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dropdownlist</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDropdownlist(Dropdownlist object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Image</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Image</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseImage(Image object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>List</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>List</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseList(List object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Output</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Output</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOutput(Output object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Iteration Filter</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Iteration Filter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIterationFilter(IterationFilter object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input Text</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input Text</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInputText(InputText object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Page View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Page View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePageView(PageView object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Site View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Site View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSiteView(SiteView object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Static Container</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Static Container</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStaticContainer(StaticContainer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Text Area</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Text Area</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTextArea(TextArea object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Selection</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Selection</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSelection(Selection object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInput(Input object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Iteration Container</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Iteration Container</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIterationContainer(IterationContainer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input Form</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input Form</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInputForm(InputForm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Check List</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Check List</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCheckList(CheckList object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Element View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Element View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElementView(ElementView object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Radio Button Group</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Radio Button Group</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRadioButtonGroup(RadioButtonGroup object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Container View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Container View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContainerView(ContainerView object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>File Upload</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>File Upload</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFileUpload(FileUpload object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //ClassLayout2FrontendSwitch
