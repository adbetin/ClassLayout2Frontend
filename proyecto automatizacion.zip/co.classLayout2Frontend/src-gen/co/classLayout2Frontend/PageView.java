/**
 */
package co.classLayout2Frontend;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Page View</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.PageView#getName <em>Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.PageView#getElementViews <em>Element Views</em>}</li>
 *   <li>{@link co.classLayout2Frontend.PageView#getLayoutType <em>Layout Type</em>}</li>
 * </ul>
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getPageView()
 * @model
 * @generated
 */
public interface PageView extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getPageView_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.PageView#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Element Views</b></em>' reference list.
	 * The list contents are of type {@link co.classLayout2Frontend.ElementView}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Element Views</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Element Views</em>' reference list.
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getPageView_ElementViews()
	 * @model
	 * @generated
	 */
	EList<ElementView> getElementViews();

	/**
	 * Returns the value of the '<em><b>Layout Type</b></em>' attribute.
	 * The literals are from the enumeration {@link co.classLayout2Frontend.LayoutType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Layout Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layout Type</em>' attribute.
	 * @see co.classLayout2Frontend.LayoutType
	 * @see #setLayoutType(LayoutType)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getPageView_LayoutType()
	 * @model
	 * @generated
	 */
	LayoutType getLayoutType();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.PageView#getLayoutType <em>Layout Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Layout Type</em>' attribute.
	 * @see co.classLayout2Frontend.LayoutType
	 * @see #getLayoutType()
	 * @generated
	 */
	void setLayoutType(LayoutType value);

} // PageView
