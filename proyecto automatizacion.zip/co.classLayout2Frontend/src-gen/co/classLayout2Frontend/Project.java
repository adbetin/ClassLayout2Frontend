/**
 */
package co.classLayout2Frontend;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Project</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.Project#getName <em>Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.Project#getEntitiesmodel <em>Entitiesmodel</em>}</li>
 *   <li>{@link co.classLayout2Frontend.Project#getSiteViews <em>Site Views</em>}</li>
 *   <li>{@link co.classLayout2Frontend.Project#getPageViews <em>Page Views</em>}</li>
 *   <li>{@link co.classLayout2Frontend.Project#getContainerViews <em>Container Views</em>}</li>
 * </ul>
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getProject()
 * @model
 * @generated
 */
public interface Project extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getProject_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.Project#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Entitiesmodel</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entitiesmodel</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entitiesmodel</em>' containment reference.
	 * @see #setEntitiesmodel(EntitiesModel)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getProject_Entitiesmodel()
	 * @model containment="true"
	 * @generated
	 */
	EntitiesModel getEntitiesmodel();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.Project#getEntitiesmodel <em>Entitiesmodel</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entitiesmodel</em>' containment reference.
	 * @see #getEntitiesmodel()
	 * @generated
	 */
	void setEntitiesmodel(EntitiesModel value);

	/**
	 * Returns the value of the '<em><b>Site Views</b></em>' containment reference list.
	 * The list contents are of type {@link co.classLayout2Frontend.SiteView}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Site Views</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Site Views</em>' containment reference list.
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getProject_SiteViews()
	 * @model containment="true"
	 * @generated
	 */
	EList<SiteView> getSiteViews();

	/**
	 * Returns the value of the '<em><b>Page Views</b></em>' containment reference list.
	 * The list contents are of type {@link co.classLayout2Frontend.PageView}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Page Views</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Page Views</em>' containment reference list.
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getProject_PageViews()
	 * @model containment="true"
	 * @generated
	 */
	EList<PageView> getPageViews();

	/**
	 * Returns the value of the '<em><b>Container Views</b></em>' containment reference list.
	 * The list contents are of type {@link co.classLayout2Frontend.ContainerView}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Container Views</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container Views</em>' containment reference list.
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getProject_ContainerViews()
	 * @model containment="true"
	 * @generated
	 */
	EList<ContainerView> getContainerViews();

} // Project
