/**
 */
package co.classLayout2Frontend;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see co.classLayout2Frontend.ClassLayout2FrontendFactory
 * @model kind="package"
 * @generated
 */
public interface ClassLayout2FrontendPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "classLayout2Frontend";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.classlayout2frontend.com/classLayout2Frontend";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "classLayout2Frontend";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ClassLayout2FrontendPackage eINSTANCE = co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl.init();

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.ProjectImpl <em>Project</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.ProjectImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getProject()
	 * @generated
	 */
	int PROJECT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Entitiesmodel</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__ENTITIESMODEL = 1;

	/**
	 * The feature id for the '<em><b>Site Views</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__SITE_VIEWS = 2;

	/**
	 * The feature id for the '<em><b>Page Views</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__PAGE_VIEWS = 3;

	/**
	 * The feature id for the '<em><b>Container Views</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__CONTAINER_VIEWS = 4;

	/**
	 * The number of structural features of the '<em>Project</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Project</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.EntityModelElementImpl <em>Entity Model Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.EntityModelElementImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEntityModelElement()
	 * @generated
	 */
	int ENTITY_MODEL_ELEMENT = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_MODEL_ELEMENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_MODEL_ELEMENT__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_MODEL_ELEMENT__DISPLAY_NAME = 2;

	/**
	 * The number of structural features of the '<em>Entity Model Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_MODEL_ELEMENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Entity Model Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_MODEL_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.StructuralFeatureImpl <em>Structural Feature</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.StructuralFeatureImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getStructuralFeature()
	 * @generated
	 */
	int STRUCTURAL_FEATURE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRUCTURAL_FEATURE__NAME = ENTITY_MODEL_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRUCTURAL_FEATURE__DESCRIPTION = ENTITY_MODEL_ELEMENT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRUCTURAL_FEATURE__DISPLAY_NAME = ENTITY_MODEL_ELEMENT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Required</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRUCTURAL_FEATURE__REQUIRED = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Structural Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRUCTURAL_FEATURE_FEATURE_COUNT = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Structural Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRUCTURAL_FEATURE_OPERATION_COUNT = ENTITY_MODEL_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.AssociationImpl <em>Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.AssociationImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getAssociation()
	 * @generated
	 */
	int ASSOCIATION = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__NAME = STRUCTURAL_FEATURE__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__DESCRIPTION = STRUCTURAL_FEATURE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__DISPLAY_NAME = STRUCTURAL_FEATURE__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Required</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__REQUIRED = STRUCTURAL_FEATURE__REQUIRED;

	/**
	 * The feature id for the '<em><b>Many</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__MANY = STRUCTURAL_FEATURE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__TARGET = STRUCTURAL_FEATURE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_FEATURE_COUNT = STRUCTURAL_FEATURE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_OPERATION_COUNT = STRUCTURAL_FEATURE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.CompositionImpl <em>Composition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.CompositionImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getComposition()
	 * @generated
	 */
	int COMPOSITION = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__NAME = ASSOCIATION__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__DESCRIPTION = ASSOCIATION__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__DISPLAY_NAME = ASSOCIATION__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Required</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__REQUIRED = ASSOCIATION__REQUIRED;

	/**
	 * The feature id for the '<em><b>Many</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__MANY = ASSOCIATION__MANY;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__TARGET = ASSOCIATION__TARGET;

	/**
	 * The number of structural features of the '<em>Composition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_FEATURE_COUNT = ASSOCIATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Composition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_OPERATION_COUNT = ASSOCIATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.PropertyTypeImpl <em>Property Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.PropertyTypeImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getPropertyType()
	 * @generated
	 */
	int PROPERTY_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_TYPE__NAME = ENTITY_MODEL_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_TYPE__DESCRIPTION = ENTITY_MODEL_ELEMENT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_TYPE__DISPLAY_NAME = ENTITY_MODEL_ELEMENT__DISPLAY_NAME;

	/**
	 * The number of structural features of the '<em>Property Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_TYPE_FEATURE_COUNT = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Property Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_TYPE_OPERATION_COUNT = ENTITY_MODEL_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.PropertyImpl <em>Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.PropertyImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getProperty()
	 * @generated
	 */
	int PROPERTY = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__NAME = STRUCTURAL_FEATURE__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__DESCRIPTION = STRUCTURAL_FEATURE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__DISPLAY_NAME = STRUCTURAL_FEATURE__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Required</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__REQUIRED = STRUCTURAL_FEATURE__REQUIRED;

	/**
	 * The feature id for the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__TYPE = STRUCTURAL_FEATURE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Default Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__DEFAULT_VALUE = STRUCTURAL_FEATURE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_FEATURE_COUNT = STRUCTURAL_FEATURE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_OPERATION_COUNT = STRUCTURAL_FEATURE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.EntitiesModelImpl <em>Entities Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.EntitiesModelImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEntitiesModel()
	 * @generated
	 */
	int ENTITIES_MODEL = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITIES_MODEL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Model Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITIES_MODEL__MODEL_ELEMENTS = 1;

	/**
	 * The number of structural features of the '<em>Entities Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITIES_MODEL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Entities Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITIES_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.EntityImpl <em>Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.EntityImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEntity()
	 * @generated
	 */
	int ENTITY = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__NAME = ENTITY_MODEL_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__DESCRIPTION = ENTITY_MODEL_ELEMENT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__DISPLAY_NAME = ENTITY_MODEL_ELEMENT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Superclass</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__SUPERCLASS = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is Abstract</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__IS_ABSTRACT = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Structural Features</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__STRUCTURAL_FEATURES = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_FEATURE_COUNT = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_OPERATION_COUNT = ENTITY_MODEL_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.PrimitiveTypeImpl <em>Primitive Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.PrimitiveTypeImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getPrimitiveType()
	 * @generated
	 */
	int PRIMITIVE_TYPE = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMITIVE_TYPE__NAME = PROPERTY_TYPE__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMITIVE_TYPE__DESCRIPTION = PROPERTY_TYPE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMITIVE_TYPE__DISPLAY_NAME = PROPERTY_TYPE__DISPLAY_NAME;

	/**
	 * The number of structural features of the '<em>Primitive Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMITIVE_TYPE_FEATURE_COUNT = PROPERTY_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Primitive Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIMITIVE_TYPE_OPERATION_COUNT = PROPERTY_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.LiteralImpl <em>Literal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.LiteralImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getLiteral()
	 * @generated
	 */
	int LITERAL = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL__NAME = ENTITY_MODEL_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL__DESCRIPTION = ENTITY_MODEL_ELEMENT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL__DISPLAY_NAME = ENTITY_MODEL_ELEMENT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL__VALUE = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Literal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL_FEATURE_COUNT = ENTITY_MODEL_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Literal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LITERAL_OPERATION_COUNT = ENTITY_MODEL_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.EnumerationImpl <em>Enumeration</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.EnumerationImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEnumeration()
	 * @generated
	 */
	int ENUMERATION = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATION__NAME = PROPERTY_TYPE__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATION__DESCRIPTION = PROPERTY_TYPE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATION__DISPLAY_NAME = PROPERTY_TYPE__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Literals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATION__LITERALS = PROPERTY_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Enumeration</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATION_FEATURE_COUNT = PROPERTY_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Enumeration</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUMERATION_OPERATION_COUNT = PROPERTY_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.ReferenceImpl <em>Reference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.ReferenceImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getReference()
	 * @generated
	 */
	int REFERENCE = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__NAME = ASSOCIATION__NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__DESCRIPTION = ASSOCIATION__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__DISPLAY_NAME = ASSOCIATION__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Required</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__REQUIRED = ASSOCIATION__REQUIRED;

	/**
	 * The feature id for the '<em><b>Many</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__MANY = ASSOCIATION__MANY;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__TARGET = ASSOCIATION__TARGET;

	/**
	 * The number of structural features of the '<em>Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_FEATURE_COUNT = ASSOCIATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_OPERATION_COUNT = ASSOCIATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.ElementViewImpl <em>Element View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.ElementViewImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getElementView()
	 * @generated
	 */
	int ELEMENT_VIEW = 30;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_VIEW__NAME = 0;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_VIEW__DISPLAY_NAME = 1;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_VIEW__DESCRIPTION = 2;

	/**
	 * The number of structural features of the '<em>Element View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_VIEW_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Element View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_VIEW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.AtomicViewImpl <em>Atomic View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.AtomicViewImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getAtomicView()
	 * @generated
	 */
	int ATOMIC_VIEW = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATOMIC_VIEW__NAME = ELEMENT_VIEW__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATOMIC_VIEW__DISPLAY_NAME = ELEMENT_VIEW__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATOMIC_VIEW__DESCRIPTION = ELEMENT_VIEW__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATOMIC_VIEW__PROPERTY = ELEMENT_VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Atomic View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATOMIC_VIEW_FEATURE_COUNT = ELEMENT_VIEW_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Atomic View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATOMIC_VIEW_OPERATION_COUNT = ELEMENT_VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.InputImpl <em>Input</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.InputImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getInput()
	 * @generated
	 */
	int INPUT = 26;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__NAME = ATOMIC_VIEW__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__DISPLAY_NAME = ATOMIC_VIEW__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__DESCRIPTION = ATOMIC_VIEW__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__PROPERTY = ATOMIC_VIEW__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT__LABEL = ATOMIC_VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FEATURE_COUNT = ATOMIC_VIEW_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_OPERATION_COUNT = ATOMIC_VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.SelectionImpl <em>Selection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.SelectionImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getSelection()
	 * @generated
	 */
	int SELECTION = 25;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION__NAME = INPUT__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION__DISPLAY_NAME = INPUT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION__DESCRIPTION = INPUT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION__PROPERTY = INPUT__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION__LABEL = INPUT__LABEL;

	/**
	 * The number of structural features of the '<em>Selection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION_FEATURE_COUNT = INPUT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Selection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECTION_OPERATION_COUNT = INPUT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.AutocompleteImpl <em>Autocomplete</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.AutocompleteImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getAutocomplete()
	 * @generated
	 */
	int AUTOCOMPLETE = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE__NAME = SELECTION__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE__DISPLAY_NAME = SELECTION__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE__DESCRIPTION = SELECTION__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE__PROPERTY = SELECTION__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE__LABEL = SELECTION__LABEL;

	/**
	 * The feature id for the '<em><b>Multiple</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE__MULTIPLE = SELECTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Autocomplete</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE_FEATURE_COUNT = SELECTION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Autocomplete</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOCOMPLETE_OPERATION_COUNT = SELECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.DropdownlistImpl <em>Dropdownlist</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.DropdownlistImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getDropdownlist()
	 * @generated
	 */
	int DROPDOWNLIST = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DROPDOWNLIST__NAME = SELECTION__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DROPDOWNLIST__DISPLAY_NAME = SELECTION__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DROPDOWNLIST__DESCRIPTION = SELECTION__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DROPDOWNLIST__PROPERTY = SELECTION__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DROPDOWNLIST__LABEL = SELECTION__LABEL;

	/**
	 * The number of structural features of the '<em>Dropdownlist</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DROPDOWNLIST_FEATURE_COUNT = SELECTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Dropdownlist</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DROPDOWNLIST_OPERATION_COUNT = SELECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.OutputImpl <em>Output</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.OutputImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getOutput()
	 * @generated
	 */
	int OUTPUT = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__NAME = ATOMIC_VIEW__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__DISPLAY_NAME = ATOMIC_VIEW__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__DESCRIPTION = ATOMIC_VIEW__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__PROPERTY = ATOMIC_VIEW__PROPERTY;

	/**
	 * The number of structural features of the '<em>Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_FEATURE_COUNT = ATOMIC_VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_OPERATION_COUNT = ATOMIC_VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.ImageImpl <em>Image</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.ImageImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getImage()
	 * @generated
	 */
	int IMAGE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__NAME = OUTPUT__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__DISPLAY_NAME = OUTPUT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__DESCRIPTION = OUTPUT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__PROPERTY = OUTPUT__PROPERTY;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__WIDTH = OUTPUT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__HEIGHT = OUTPUT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_FEATURE_COUNT = OUTPUT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_OPERATION_COUNT = OUTPUT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.ListImpl <em>List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.ListImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getList()
	 * @generated
	 */
	int LIST = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__NAME = SELECTION__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__DISPLAY_NAME = SELECTION__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__DESCRIPTION = SELECTION__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__PROPERTY = SELECTION__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__LABEL = SELECTION__LABEL;

	/**
	 * The feature id for the '<em><b>Multiple</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__MULTIPLE = SELECTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_FEATURE_COUNT = SELECTION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_OPERATION_COUNT = SELECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.IterationFilterImpl <em>Iteration Filter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.IterationFilterImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getIterationFilter()
	 * @generated
	 */
	int ITERATION_FILTER = 19;

	/**
	 * The feature id for the '<em><b>Input</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_FILTER__INPUT = 0;

	/**
	 * The number of structural features of the '<em>Iteration Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_FILTER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Iteration Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_FILTER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.InputTextImpl <em>Input Text</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.InputTextImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getInputText()
	 * @generated
	 */
	int INPUT_TEXT = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT__NAME = INPUT__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT__DISPLAY_NAME = INPUT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT__DESCRIPTION = INPUT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT__PROPERTY = INPUT__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT__LABEL = INPUT__LABEL;

	/**
	 * The feature id for the '<em><b>Multiline</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT__MULTILINE = INPUT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Input Text</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT_FEATURE_COUNT = INPUT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Input Text</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_TEXT_OPERATION_COUNT = INPUT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.PageViewImpl <em>Page View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.PageViewImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getPageView()
	 * @generated
	 */
	int PAGE_VIEW = 21;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE_VIEW__NAME = 0;

	/**
	 * The feature id for the '<em><b>Element Views</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE_VIEW__ELEMENT_VIEWS = 1;

	/**
	 * The feature id for the '<em><b>Layout Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE_VIEW__LAYOUT_TYPE = 2;

	/**
	 * The number of structural features of the '<em>Page View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE_VIEW_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Page View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE_VIEW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.SiteViewImpl <em>Site View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.SiteViewImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getSiteView()
	 * @generated
	 */
	int SITE_VIEW = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITE_VIEW__NAME = 0;

	/**
	 * The feature id for the '<em><b>Template Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITE_VIEW__TEMPLATE_NAME = 1;

	/**
	 * The feature id for the '<em><b>Template Color</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITE_VIEW__TEMPLATE_COLOR = 2;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITE_VIEW__DISPLAY_NAME = 3;

	/**
	 * The feature id for the '<em><b>Page Views</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITE_VIEW__PAGE_VIEWS = 4;

	/**
	 * The number of structural features of the '<em>Site View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITE_VIEW_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Site View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SITE_VIEW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.ContainerViewImpl <em>Container View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.ContainerViewImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getContainerView()
	 * @generated
	 */
	int CONTAINER_VIEW = 32;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_VIEW__NAME = ELEMENT_VIEW__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_VIEW__DISPLAY_NAME = ELEMENT_VIEW__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_VIEW__DESCRIPTION = ELEMENT_VIEW__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_VIEW__ELEMENTS = ELEMENT_VIEW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_VIEW__ENTITY = ELEMENT_VIEW_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Container View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_VIEW_FEATURE_COUNT = ELEMENT_VIEW_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Container View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_VIEW_OPERATION_COUNT = ELEMENT_VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.StaticContainerImpl <em>Static Container</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.StaticContainerImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getStaticContainer()
	 * @generated
	 */
	int STATIC_CONTAINER = 23;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATIC_CONTAINER__NAME = CONTAINER_VIEW__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATIC_CONTAINER__DISPLAY_NAME = CONTAINER_VIEW__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATIC_CONTAINER__DESCRIPTION = CONTAINER_VIEW__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATIC_CONTAINER__ELEMENTS = CONTAINER_VIEW__ELEMENTS;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATIC_CONTAINER__ENTITY = CONTAINER_VIEW__ENTITY;

	/**
	 * The number of structural features of the '<em>Static Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATIC_CONTAINER_FEATURE_COUNT = CONTAINER_VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Static Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATIC_CONTAINER_OPERATION_COUNT = CONTAINER_VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.TextAreaImpl <em>Text Area</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.TextAreaImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getTextArea()
	 * @generated
	 */
	int TEXT_AREA = 24;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA__NAME = OUTPUT__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA__DISPLAY_NAME = OUTPUT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA__DESCRIPTION = OUTPUT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA__PROPERTY = OUTPUT__PROPERTY;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA__VALUE = OUTPUT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA__IS_TITLE = OUTPUT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Text Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA_FEATURE_COUNT = OUTPUT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Text Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_AREA_OPERATION_COUNT = OUTPUT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.IterationContainerImpl <em>Iteration Container</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.IterationContainerImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getIterationContainer()
	 * @generated
	 */
	int ITERATION_CONTAINER = 27;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER__NAME = CONTAINER_VIEW__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER__DISPLAY_NAME = CONTAINER_VIEW__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER__DESCRIPTION = CONTAINER_VIEW__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER__ELEMENTS = CONTAINER_VIEW__ELEMENTS;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER__ENTITY = CONTAINER_VIEW__ENTITY;

	/**
	 * The feature id for the '<em><b>Iteration Filters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER__ITERATION_FILTERS = CONTAINER_VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Iteration Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER_FEATURE_COUNT = CONTAINER_VIEW_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Iteration Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITERATION_CONTAINER_OPERATION_COUNT = CONTAINER_VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.InputFormImpl <em>Input Form</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.InputFormImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getInputForm()
	 * @generated
	 */
	int INPUT_FORM = 28;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FORM__NAME = CONTAINER_VIEW__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FORM__DISPLAY_NAME = CONTAINER_VIEW__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FORM__DESCRIPTION = CONTAINER_VIEW__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FORM__ELEMENTS = CONTAINER_VIEW__ELEMENTS;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FORM__ENTITY = CONTAINER_VIEW__ENTITY;

	/**
	 * The number of structural features of the '<em>Input Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FORM_FEATURE_COUNT = CONTAINER_VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Input Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_FORM_OPERATION_COUNT = CONTAINER_VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.CheckListImpl <em>Check List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.CheckListImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getCheckList()
	 * @generated
	 */
	int CHECK_LIST = 29;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_LIST__NAME = SELECTION__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_LIST__DISPLAY_NAME = SELECTION__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_LIST__DESCRIPTION = SELECTION__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_LIST__PROPERTY = SELECTION__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_LIST__LABEL = SELECTION__LABEL;

	/**
	 * The number of structural features of the '<em>Check List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_LIST_FEATURE_COUNT = SELECTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Check List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_LIST_OPERATION_COUNT = SELECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.RadioButtonGroupImpl <em>Radio Button Group</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.RadioButtonGroupImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getRadioButtonGroup()
	 * @generated
	 */
	int RADIO_BUTTON_GROUP = 31;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RADIO_BUTTON_GROUP__NAME = SELECTION__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RADIO_BUTTON_GROUP__DISPLAY_NAME = SELECTION__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RADIO_BUTTON_GROUP__DESCRIPTION = SELECTION__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RADIO_BUTTON_GROUP__PROPERTY = SELECTION__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RADIO_BUTTON_GROUP__LABEL = SELECTION__LABEL;

	/**
	 * The number of structural features of the '<em>Radio Button Group</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RADIO_BUTTON_GROUP_FEATURE_COUNT = SELECTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Radio Button Group</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RADIO_BUTTON_GROUP_OPERATION_COUNT = SELECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.impl.FileUploadImpl <em>File Upload</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.impl.FileUploadImpl
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getFileUpload()
	 * @generated
	 */
	int FILE_UPLOAD = 33;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_UPLOAD__NAME = INPUT__NAME;

	/**
	 * The feature id for the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_UPLOAD__DISPLAY_NAME = INPUT__DISPLAY_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_UPLOAD__DESCRIPTION = INPUT__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Property</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_UPLOAD__PROPERTY = INPUT__PROPERTY;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_UPLOAD__LABEL = INPUT__LABEL;

	/**
	 * The number of structural features of the '<em>File Upload</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_UPLOAD_FEATURE_COUNT = INPUT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>File Upload</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_UPLOAD_OPERATION_COUNT = INPUT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link co.classLayout2Frontend.LayoutType <em>Layout Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see co.classLayout2Frontend.LayoutType
	 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getLayoutType()
	 * @generated
	 */
	int LAYOUT_TYPE = 34;

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Project <em>Project</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Project</em>'.
	 * @see co.classLayout2Frontend.Project
	 * @generated
	 */
	EClass getProject();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Project#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see co.classLayout2Frontend.Project#getName()
	 * @see #getProject()
	 * @generated
	 */
	EAttribute getProject_Name();

	/**
	 * Returns the meta object for the containment reference '{@link co.classLayout2Frontend.Project#getEntitiesmodel <em>Entitiesmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Entitiesmodel</em>'.
	 * @see co.classLayout2Frontend.Project#getEntitiesmodel()
	 * @see #getProject()
	 * @generated
	 */
	EReference getProject_Entitiesmodel();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.Project#getSiteViews <em>Site Views</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Site Views</em>'.
	 * @see co.classLayout2Frontend.Project#getSiteViews()
	 * @see #getProject()
	 * @generated
	 */
	EReference getProject_SiteViews();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.Project#getPageViews <em>Page Views</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Page Views</em>'.
	 * @see co.classLayout2Frontend.Project#getPageViews()
	 * @see #getProject()
	 * @generated
	 */
	EReference getProject_PageViews();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.Project#getContainerViews <em>Container Views</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Container Views</em>'.
	 * @see co.classLayout2Frontend.Project#getContainerViews()
	 * @see #getProject()
	 * @generated
	 */
	EReference getProject_ContainerViews();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Composition <em>Composition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composition</em>'.
	 * @see co.classLayout2Frontend.Composition
	 * @generated
	 */
	EClass getComposition();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Association <em>Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association</em>'.
	 * @see co.classLayout2Frontend.Association
	 * @generated
	 */
	EClass getAssociation();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Association#isMany <em>Many</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Many</em>'.
	 * @see co.classLayout2Frontend.Association#isMany()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_Many();

	/**
	 * Returns the meta object for the reference '{@link co.classLayout2Frontend.Association#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see co.classLayout2Frontend.Association#getTarget()
	 * @see #getAssociation()
	 * @generated
	 */
	EReference getAssociation_Target();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.PropertyType <em>Property Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Property Type</em>'.
	 * @see co.classLayout2Frontend.PropertyType
	 * @generated
	 */
	EClass getPropertyType();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Property <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Property</em>'.
	 * @see co.classLayout2Frontend.Property
	 * @generated
	 */
	EClass getProperty();

	/**
	 * Returns the meta object for the reference '{@link co.classLayout2Frontend.Property#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Type</em>'.
	 * @see co.classLayout2Frontend.Property#getType()
	 * @see #getProperty()
	 * @generated
	 */
	EReference getProperty_Type();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Property#getDefaultValue <em>Default Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Default Value</em>'.
	 * @see co.classLayout2Frontend.Property#getDefaultValue()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_DefaultValue();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.StructuralFeature <em>Structural Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Structural Feature</em>'.
	 * @see co.classLayout2Frontend.StructuralFeature
	 * @generated
	 */
	EClass getStructuralFeature();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.StructuralFeature#isRequired <em>Required</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Required</em>'.
	 * @see co.classLayout2Frontend.StructuralFeature#isRequired()
	 * @see #getStructuralFeature()
	 * @generated
	 */
	EAttribute getStructuralFeature_Required();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.EntitiesModel <em>Entities Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entities Model</em>'.
	 * @see co.classLayout2Frontend.EntitiesModel
	 * @generated
	 */
	EClass getEntitiesModel();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.EntitiesModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see co.classLayout2Frontend.EntitiesModel#getName()
	 * @see #getEntitiesModel()
	 * @generated
	 */
	EAttribute getEntitiesModel_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.EntitiesModel#getModelElements <em>Model Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Model Elements</em>'.
	 * @see co.classLayout2Frontend.EntitiesModel#getModelElements()
	 * @see #getEntitiesModel()
	 * @generated
	 */
	EReference getEntitiesModel_ModelElements();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.EntityModelElement <em>Entity Model Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entity Model Element</em>'.
	 * @see co.classLayout2Frontend.EntityModelElement
	 * @generated
	 */
	EClass getEntityModelElement();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.EntityModelElement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see co.classLayout2Frontend.EntityModelElement#getName()
	 * @see #getEntityModelElement()
	 * @generated
	 */
	EAttribute getEntityModelElement_Name();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.EntityModelElement#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see co.classLayout2Frontend.EntityModelElement#getDescription()
	 * @see #getEntityModelElement()
	 * @generated
	 */
	EAttribute getEntityModelElement_Description();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.EntityModelElement#getDisplayName <em>Display Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Display Name</em>'.
	 * @see co.classLayout2Frontend.EntityModelElement#getDisplayName()
	 * @see #getEntityModelElement()
	 * @generated
	 */
	EAttribute getEntityModelElement_DisplayName();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Entity <em>Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entity</em>'.
	 * @see co.classLayout2Frontend.Entity
	 * @generated
	 */
	EClass getEntity();

	/**
	 * Returns the meta object for the reference '{@link co.classLayout2Frontend.Entity#getSuperclass <em>Superclass</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Superclass</em>'.
	 * @see co.classLayout2Frontend.Entity#getSuperclass()
	 * @see #getEntity()
	 * @generated
	 */
	EReference getEntity_Superclass();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Entity#isIsAbstract <em>Is Abstract</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Abstract</em>'.
	 * @see co.classLayout2Frontend.Entity#isIsAbstract()
	 * @see #getEntity()
	 * @generated
	 */
	EAttribute getEntity_IsAbstract();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.Entity#getStructuralFeatures <em>Structural Features</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Structural Features</em>'.
	 * @see co.classLayout2Frontend.Entity#getStructuralFeatures()
	 * @see #getEntity()
	 * @generated
	 */
	EReference getEntity_StructuralFeatures();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.PrimitiveType <em>Primitive Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Primitive Type</em>'.
	 * @see co.classLayout2Frontend.PrimitiveType
	 * @generated
	 */
	EClass getPrimitiveType();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Literal <em>Literal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Literal</em>'.
	 * @see co.classLayout2Frontend.Literal
	 * @generated
	 */
	EClass getLiteral();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Literal#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see co.classLayout2Frontend.Literal#getValue()
	 * @see #getLiteral()
	 * @generated
	 */
	EAttribute getLiteral_Value();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Enumeration <em>Enumeration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enumeration</em>'.
	 * @see co.classLayout2Frontend.Enumeration
	 * @generated
	 */
	EClass getEnumeration();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.Enumeration#getLiterals <em>Literals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Literals</em>'.
	 * @see co.classLayout2Frontend.Enumeration#getLiterals()
	 * @see #getEnumeration()
	 * @generated
	 */
	EReference getEnumeration_Literals();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Reference <em>Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reference</em>'.
	 * @see co.classLayout2Frontend.Reference
	 * @generated
	 */
	EClass getReference();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.AtomicView <em>Atomic View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Atomic View</em>'.
	 * @see co.classLayout2Frontend.AtomicView
	 * @generated
	 */
	EClass getAtomicView();

	/**
	 * Returns the meta object for the reference '{@link co.classLayout2Frontend.AtomicView#getProperty <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Property</em>'.
	 * @see co.classLayout2Frontend.AtomicView#getProperty()
	 * @see #getAtomicView()
	 * @generated
	 */
	EReference getAtomicView_Property();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Autocomplete <em>Autocomplete</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Autocomplete</em>'.
	 * @see co.classLayout2Frontend.Autocomplete
	 * @generated
	 */
	EClass getAutocomplete();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Autocomplete#isMultiple <em>Multiple</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multiple</em>'.
	 * @see co.classLayout2Frontend.Autocomplete#isMultiple()
	 * @see #getAutocomplete()
	 * @generated
	 */
	EAttribute getAutocomplete_Multiple();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Dropdownlist <em>Dropdownlist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dropdownlist</em>'.
	 * @see co.classLayout2Frontend.Dropdownlist
	 * @generated
	 */
	EClass getDropdownlist();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Image <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Image</em>'.
	 * @see co.classLayout2Frontend.Image
	 * @generated
	 */
	EClass getImage();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Image#getWidth <em>Width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Width</em>'.
	 * @see co.classLayout2Frontend.Image#getWidth()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_Width();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Image#getHeight <em>Height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Height</em>'.
	 * @see co.classLayout2Frontend.Image#getHeight()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_Height();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>List</em>'.
	 * @see co.classLayout2Frontend.List
	 * @generated
	 */
	EClass getList();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.List#isMultiple <em>Multiple</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multiple</em>'.
	 * @see co.classLayout2Frontend.List#isMultiple()
	 * @see #getList()
	 * @generated
	 */
	EAttribute getList_Multiple();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Output <em>Output</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Output</em>'.
	 * @see co.classLayout2Frontend.Output
	 * @generated
	 */
	EClass getOutput();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.IterationFilter <em>Iteration Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Iteration Filter</em>'.
	 * @see co.classLayout2Frontend.IterationFilter
	 * @generated
	 */
	EClass getIterationFilter();

	/**
	 * Returns the meta object for the reference '{@link co.classLayout2Frontend.IterationFilter#getInput <em>Input</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Input</em>'.
	 * @see co.classLayout2Frontend.IterationFilter#getInput()
	 * @see #getIterationFilter()
	 * @generated
	 */
	EReference getIterationFilter_Input();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.InputText <em>Input Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Text</em>'.
	 * @see co.classLayout2Frontend.InputText
	 * @generated
	 */
	EClass getInputText();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.InputText#isMultiline <em>Multiline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multiline</em>'.
	 * @see co.classLayout2Frontend.InputText#isMultiline()
	 * @see #getInputText()
	 * @generated
	 */
	EAttribute getInputText_Multiline();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.PageView <em>Page View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Page View</em>'.
	 * @see co.classLayout2Frontend.PageView
	 * @generated
	 */
	EClass getPageView();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.PageView#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see co.classLayout2Frontend.PageView#getName()
	 * @see #getPageView()
	 * @generated
	 */
	EAttribute getPageView_Name();

	/**
	 * Returns the meta object for the reference list '{@link co.classLayout2Frontend.PageView#getElementViews <em>Element Views</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Element Views</em>'.
	 * @see co.classLayout2Frontend.PageView#getElementViews()
	 * @see #getPageView()
	 * @generated
	 */
	EReference getPageView_ElementViews();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.PageView#getLayoutType <em>Layout Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Layout Type</em>'.
	 * @see co.classLayout2Frontend.PageView#getLayoutType()
	 * @see #getPageView()
	 * @generated
	 */
	EAttribute getPageView_LayoutType();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.SiteView <em>Site View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Site View</em>'.
	 * @see co.classLayout2Frontend.SiteView
	 * @generated
	 */
	EClass getSiteView();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.SiteView#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see co.classLayout2Frontend.SiteView#getName()
	 * @see #getSiteView()
	 * @generated
	 */
	EAttribute getSiteView_Name();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.SiteView#getTemplateName <em>Template Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Template Name</em>'.
	 * @see co.classLayout2Frontend.SiteView#getTemplateName()
	 * @see #getSiteView()
	 * @generated
	 */
	EAttribute getSiteView_TemplateName();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.SiteView#getTemplateColor <em>Template Color</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Template Color</em>'.
	 * @see co.classLayout2Frontend.SiteView#getTemplateColor()
	 * @see #getSiteView()
	 * @generated
	 */
	EAttribute getSiteView_TemplateColor();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.SiteView#getDisplayName <em>Display Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Display Name</em>'.
	 * @see co.classLayout2Frontend.SiteView#getDisplayName()
	 * @see #getSiteView()
	 * @generated
	 */
	EAttribute getSiteView_DisplayName();

	/**
	 * Returns the meta object for the reference list '{@link co.classLayout2Frontend.SiteView#getPageViews <em>Page Views</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Page Views</em>'.
	 * @see co.classLayout2Frontend.SiteView#getPageViews()
	 * @see #getSiteView()
	 * @generated
	 */
	EReference getSiteView_PageViews();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.StaticContainer <em>Static Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Static Container</em>'.
	 * @see co.classLayout2Frontend.StaticContainer
	 * @generated
	 */
	EClass getStaticContainer();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.TextArea <em>Text Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Text Area</em>'.
	 * @see co.classLayout2Frontend.TextArea
	 * @generated
	 */
	EClass getTextArea();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.TextArea#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see co.classLayout2Frontend.TextArea#getValue()
	 * @see #getTextArea()
	 * @generated
	 */
	EAttribute getTextArea_Value();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.TextArea#isIsTitle <em>Is Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Title</em>'.
	 * @see co.classLayout2Frontend.TextArea#isIsTitle()
	 * @see #getTextArea()
	 * @generated
	 */
	EAttribute getTextArea_IsTitle();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Selection <em>Selection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Selection</em>'.
	 * @see co.classLayout2Frontend.Selection
	 * @generated
	 */
	EClass getSelection();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.Input <em>Input</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input</em>'.
	 * @see co.classLayout2Frontend.Input
	 * @generated
	 */
	EClass getInput();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.Input#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see co.classLayout2Frontend.Input#getLabel()
	 * @see #getInput()
	 * @generated
	 */
	EAttribute getInput_Label();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.IterationContainer <em>Iteration Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Iteration Container</em>'.
	 * @see co.classLayout2Frontend.IterationContainer
	 * @generated
	 */
	EClass getIterationContainer();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.IterationContainer#getIterationFilters <em>Iteration Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Iteration Filters</em>'.
	 * @see co.classLayout2Frontend.IterationContainer#getIterationFilters()
	 * @see #getIterationContainer()
	 * @generated
	 */
	EReference getIterationContainer_IterationFilters();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.InputForm <em>Input Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Form</em>'.
	 * @see co.classLayout2Frontend.InputForm
	 * @generated
	 */
	EClass getInputForm();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.CheckList <em>Check List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Check List</em>'.
	 * @see co.classLayout2Frontend.CheckList
	 * @generated
	 */
	EClass getCheckList();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.ElementView <em>Element View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Element View</em>'.
	 * @see co.classLayout2Frontend.ElementView
	 * @generated
	 */
	EClass getElementView();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.ElementView#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see co.classLayout2Frontend.ElementView#getName()
	 * @see #getElementView()
	 * @generated
	 */
	EAttribute getElementView_Name();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.ElementView#getDisplayName <em>Display Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Display Name</em>'.
	 * @see co.classLayout2Frontend.ElementView#getDisplayName()
	 * @see #getElementView()
	 * @generated
	 */
	EAttribute getElementView_DisplayName();

	/**
	 * Returns the meta object for the attribute '{@link co.classLayout2Frontend.ElementView#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see co.classLayout2Frontend.ElementView#getDescription()
	 * @see #getElementView()
	 * @generated
	 */
	EAttribute getElementView_Description();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.RadioButtonGroup <em>Radio Button Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Radio Button Group</em>'.
	 * @see co.classLayout2Frontend.RadioButtonGroup
	 * @generated
	 */
	EClass getRadioButtonGroup();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.ContainerView <em>Container View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Container View</em>'.
	 * @see co.classLayout2Frontend.ContainerView
	 * @generated
	 */
	EClass getContainerView();

	/**
	 * Returns the meta object for the containment reference list '{@link co.classLayout2Frontend.ContainerView#getElements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Elements</em>'.
	 * @see co.classLayout2Frontend.ContainerView#getElements()
	 * @see #getContainerView()
	 * @generated
	 */
	EReference getContainerView_Elements();

	/**
	 * Returns the meta object for the reference '{@link co.classLayout2Frontend.ContainerView#getEntity <em>Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Entity</em>'.
	 * @see co.classLayout2Frontend.ContainerView#getEntity()
	 * @see #getContainerView()
	 * @generated
	 */
	EReference getContainerView_Entity();

	/**
	 * Returns the meta object for class '{@link co.classLayout2Frontend.FileUpload <em>File Upload</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>File Upload</em>'.
	 * @see co.classLayout2Frontend.FileUpload
	 * @generated
	 */
	EClass getFileUpload();

	/**
	 * Returns the meta object for enum '{@link co.classLayout2Frontend.LayoutType <em>Layout Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Layout Type</em>'.
	 * @see co.classLayout2Frontend.LayoutType
	 * @generated
	 */
	EEnum getLayoutType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ClassLayout2FrontendFactory getClassLayout2FrontendFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.ProjectImpl <em>Project</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.ProjectImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getProject()
		 * @generated
		 */
		EClass PROJECT = eINSTANCE.getProject();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROJECT__NAME = eINSTANCE.getProject_Name();

		/**
		 * The meta object literal for the '<em><b>Entitiesmodel</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROJECT__ENTITIESMODEL = eINSTANCE.getProject_Entitiesmodel();

		/**
		 * The meta object literal for the '<em><b>Site Views</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROJECT__SITE_VIEWS = eINSTANCE.getProject_SiteViews();

		/**
		 * The meta object literal for the '<em><b>Page Views</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROJECT__PAGE_VIEWS = eINSTANCE.getProject_PageViews();

		/**
		 * The meta object literal for the '<em><b>Container Views</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROJECT__CONTAINER_VIEWS = eINSTANCE.getProject_ContainerViews();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.CompositionImpl <em>Composition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.CompositionImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getComposition()
		 * @generated
		 */
		EClass COMPOSITION = eINSTANCE.getComposition();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.AssociationImpl <em>Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.AssociationImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getAssociation()
		 * @generated
		 */
		EClass ASSOCIATION = eINSTANCE.getAssociation();

		/**
		 * The meta object literal for the '<em><b>Many</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__MANY = eINSTANCE.getAssociation_Many();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ASSOCIATION__TARGET = eINSTANCE.getAssociation_Target();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.PropertyTypeImpl <em>Property Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.PropertyTypeImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getPropertyType()
		 * @generated
		 */
		EClass PROPERTY_TYPE = eINSTANCE.getPropertyType();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.PropertyImpl <em>Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.PropertyImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getProperty()
		 * @generated
		 */
		EClass PROPERTY = eINSTANCE.getProperty();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROPERTY__TYPE = eINSTANCE.getProperty_Type();

		/**
		 * The meta object literal for the '<em><b>Default Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__DEFAULT_VALUE = eINSTANCE.getProperty_DefaultValue();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.StructuralFeatureImpl <em>Structural Feature</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.StructuralFeatureImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getStructuralFeature()
		 * @generated
		 */
		EClass STRUCTURAL_FEATURE = eINSTANCE.getStructuralFeature();

		/**
		 * The meta object literal for the '<em><b>Required</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRUCTURAL_FEATURE__REQUIRED = eINSTANCE.getStructuralFeature_Required();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.EntitiesModelImpl <em>Entities Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.EntitiesModelImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEntitiesModel()
		 * @generated
		 */
		EClass ENTITIES_MODEL = eINSTANCE.getEntitiesModel();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITIES_MODEL__NAME = eINSTANCE.getEntitiesModel_Name();

		/**
		 * The meta object literal for the '<em><b>Model Elements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITIES_MODEL__MODEL_ELEMENTS = eINSTANCE.getEntitiesModel_ModelElements();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.EntityModelElementImpl <em>Entity Model Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.EntityModelElementImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEntityModelElement()
		 * @generated
		 */
		EClass ENTITY_MODEL_ELEMENT = eINSTANCE.getEntityModelElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_MODEL_ELEMENT__NAME = eINSTANCE.getEntityModelElement_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_MODEL_ELEMENT__DESCRIPTION = eINSTANCE.getEntityModelElement_Description();

		/**
		 * The meta object literal for the '<em><b>Display Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_MODEL_ELEMENT__DISPLAY_NAME = eINSTANCE.getEntityModelElement_DisplayName();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.EntityImpl <em>Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.EntityImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEntity()
		 * @generated
		 */
		EClass ENTITY = eINSTANCE.getEntity();

		/**
		 * The meta object literal for the '<em><b>Superclass</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY__SUPERCLASS = eINSTANCE.getEntity_Superclass();

		/**
		 * The meta object literal for the '<em><b>Is Abstract</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY__IS_ABSTRACT = eINSTANCE.getEntity_IsAbstract();

		/**
		 * The meta object literal for the '<em><b>Structural Features</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY__STRUCTURAL_FEATURES = eINSTANCE.getEntity_StructuralFeatures();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.PrimitiveTypeImpl <em>Primitive Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.PrimitiveTypeImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getPrimitiveType()
		 * @generated
		 */
		EClass PRIMITIVE_TYPE = eINSTANCE.getPrimitiveType();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.LiteralImpl <em>Literal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.LiteralImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getLiteral()
		 * @generated
		 */
		EClass LITERAL = eINSTANCE.getLiteral();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LITERAL__VALUE = eINSTANCE.getLiteral_Value();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.EnumerationImpl <em>Enumeration</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.EnumerationImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getEnumeration()
		 * @generated
		 */
		EClass ENUMERATION = eINSTANCE.getEnumeration();

		/**
		 * The meta object literal for the '<em><b>Literals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENUMERATION__LITERALS = eINSTANCE.getEnumeration_Literals();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.ReferenceImpl <em>Reference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.ReferenceImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getReference()
		 * @generated
		 */
		EClass REFERENCE = eINSTANCE.getReference();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.AtomicViewImpl <em>Atomic View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.AtomicViewImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getAtomicView()
		 * @generated
		 */
		EClass ATOMIC_VIEW = eINSTANCE.getAtomicView();

		/**
		 * The meta object literal for the '<em><b>Property</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATOMIC_VIEW__PROPERTY = eINSTANCE.getAtomicView_Property();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.AutocompleteImpl <em>Autocomplete</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.AutocompleteImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getAutocomplete()
		 * @generated
		 */
		EClass AUTOCOMPLETE = eINSTANCE.getAutocomplete();

		/**
		 * The meta object literal for the '<em><b>Multiple</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUTOCOMPLETE__MULTIPLE = eINSTANCE.getAutocomplete_Multiple();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.DropdownlistImpl <em>Dropdownlist</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.DropdownlistImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getDropdownlist()
		 * @generated
		 */
		EClass DROPDOWNLIST = eINSTANCE.getDropdownlist();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.ImageImpl <em>Image</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.ImageImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getImage()
		 * @generated
		 */
		EClass IMAGE = eINSTANCE.getImage();

		/**
		 * The meta object literal for the '<em><b>Width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__WIDTH = eINSTANCE.getImage_Width();

		/**
		 * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__HEIGHT = eINSTANCE.getImage_Height();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.ListImpl <em>List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.ListImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getList()
		 * @generated
		 */
		EClass LIST = eINSTANCE.getList();

		/**
		 * The meta object literal for the '<em><b>Multiple</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIST__MULTIPLE = eINSTANCE.getList_Multiple();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.OutputImpl <em>Output</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.OutputImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getOutput()
		 * @generated
		 */
		EClass OUTPUT = eINSTANCE.getOutput();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.IterationFilterImpl <em>Iteration Filter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.IterationFilterImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getIterationFilter()
		 * @generated
		 */
		EClass ITERATION_FILTER = eINSTANCE.getIterationFilter();

		/**
		 * The meta object literal for the '<em><b>Input</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITERATION_FILTER__INPUT = eINSTANCE.getIterationFilter_Input();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.InputTextImpl <em>Input Text</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.InputTextImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getInputText()
		 * @generated
		 */
		EClass INPUT_TEXT = eINSTANCE.getInputText();

		/**
		 * The meta object literal for the '<em><b>Multiline</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_TEXT__MULTILINE = eINSTANCE.getInputText_Multiline();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.PageViewImpl <em>Page View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.PageViewImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getPageView()
		 * @generated
		 */
		EClass PAGE_VIEW = eINSTANCE.getPageView();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAGE_VIEW__NAME = eINSTANCE.getPageView_Name();

		/**
		 * The meta object literal for the '<em><b>Element Views</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGE_VIEW__ELEMENT_VIEWS = eINSTANCE.getPageView_ElementViews();

		/**
		 * The meta object literal for the '<em><b>Layout Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAGE_VIEW__LAYOUT_TYPE = eINSTANCE.getPageView_LayoutType();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.SiteViewImpl <em>Site View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.SiteViewImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getSiteView()
		 * @generated
		 */
		EClass SITE_VIEW = eINSTANCE.getSiteView();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SITE_VIEW__NAME = eINSTANCE.getSiteView_Name();

		/**
		 * The meta object literal for the '<em><b>Template Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SITE_VIEW__TEMPLATE_NAME = eINSTANCE.getSiteView_TemplateName();

		/**
		 * The meta object literal for the '<em><b>Template Color</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SITE_VIEW__TEMPLATE_COLOR = eINSTANCE.getSiteView_TemplateColor();

		/**
		 * The meta object literal for the '<em><b>Display Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SITE_VIEW__DISPLAY_NAME = eINSTANCE.getSiteView_DisplayName();

		/**
		 * The meta object literal for the '<em><b>Page Views</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SITE_VIEW__PAGE_VIEWS = eINSTANCE.getSiteView_PageViews();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.StaticContainerImpl <em>Static Container</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.StaticContainerImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getStaticContainer()
		 * @generated
		 */
		EClass STATIC_CONTAINER = eINSTANCE.getStaticContainer();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.TextAreaImpl <em>Text Area</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.TextAreaImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getTextArea()
		 * @generated
		 */
		EClass TEXT_AREA = eINSTANCE.getTextArea();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEXT_AREA__VALUE = eINSTANCE.getTextArea_Value();

		/**
		 * The meta object literal for the '<em><b>Is Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEXT_AREA__IS_TITLE = eINSTANCE.getTextArea_IsTitle();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.SelectionImpl <em>Selection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.SelectionImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getSelection()
		 * @generated
		 */
		EClass SELECTION = eINSTANCE.getSelection();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.InputImpl <em>Input</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.InputImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getInput()
		 * @generated
		 */
		EClass INPUT = eINSTANCE.getInput();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT__LABEL = eINSTANCE.getInput_Label();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.IterationContainerImpl <em>Iteration Container</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.IterationContainerImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getIterationContainer()
		 * @generated
		 */
		EClass ITERATION_CONTAINER = eINSTANCE.getIterationContainer();

		/**
		 * The meta object literal for the '<em><b>Iteration Filters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITERATION_CONTAINER__ITERATION_FILTERS = eINSTANCE.getIterationContainer_IterationFilters();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.InputFormImpl <em>Input Form</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.InputFormImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getInputForm()
		 * @generated
		 */
		EClass INPUT_FORM = eINSTANCE.getInputForm();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.CheckListImpl <em>Check List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.CheckListImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getCheckList()
		 * @generated
		 */
		EClass CHECK_LIST = eINSTANCE.getCheckList();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.ElementViewImpl <em>Element View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.ElementViewImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getElementView()
		 * @generated
		 */
		EClass ELEMENT_VIEW = eINSTANCE.getElementView();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT_VIEW__NAME = eINSTANCE.getElementView_Name();

		/**
		 * The meta object literal for the '<em><b>Display Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT_VIEW__DISPLAY_NAME = eINSTANCE.getElementView_DisplayName();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT_VIEW__DESCRIPTION = eINSTANCE.getElementView_Description();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.RadioButtonGroupImpl <em>Radio Button Group</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.RadioButtonGroupImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getRadioButtonGroup()
		 * @generated
		 */
		EClass RADIO_BUTTON_GROUP = eINSTANCE.getRadioButtonGroup();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.ContainerViewImpl <em>Container View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.ContainerViewImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getContainerView()
		 * @generated
		 */
		EClass CONTAINER_VIEW = eINSTANCE.getContainerView();

		/**
		 * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER_VIEW__ELEMENTS = eINSTANCE.getContainerView_Elements();

		/**
		 * The meta object literal for the '<em><b>Entity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER_VIEW__ENTITY = eINSTANCE.getContainerView_Entity();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.impl.FileUploadImpl <em>File Upload</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.impl.FileUploadImpl
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getFileUpload()
		 * @generated
		 */
		EClass FILE_UPLOAD = eINSTANCE.getFileUpload();

		/**
		 * The meta object literal for the '{@link co.classLayout2Frontend.LayoutType <em>Layout Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see co.classLayout2Frontend.LayoutType
		 * @see co.classLayout2Frontend.impl.ClassLayout2FrontendPackageImpl#getLayoutType()
		 * @generated
		 */
		EEnum LAYOUT_TYPE = eINSTANCE.getLayoutType();

	}

} //ClassLayout2FrontendPackage
