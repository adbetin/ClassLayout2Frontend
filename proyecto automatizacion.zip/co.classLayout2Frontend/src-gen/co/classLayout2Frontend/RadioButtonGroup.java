/**
 */
package co.classLayout2Frontend;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Radio Button Group</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getRadioButtonGroup()
 * @model
 * @generated
 */
public interface RadioButtonGroup extends Selection {
} // RadioButtonGroup
