/**
 */
package co.classLayout2Frontend;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getOutput()
 * @model abstract="true"
 * @generated
 */
public interface Output extends AtomicView {
} // Output
