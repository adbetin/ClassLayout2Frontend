/**
 */
package co.classLayout2Frontend;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getPrimitiveType()
 * @model
 * @generated
 */
public interface PrimitiveType extends PropertyType {
} // PrimitiveType
