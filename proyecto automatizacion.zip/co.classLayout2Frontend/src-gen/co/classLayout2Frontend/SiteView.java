/**
 */
package co.classLayout2Frontend;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Site View</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link co.classLayout2Frontend.SiteView#getName <em>Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.SiteView#getTemplateName <em>Template Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.SiteView#getTemplateColor <em>Template Color</em>}</li>
 *   <li>{@link co.classLayout2Frontend.SiteView#getDisplayName <em>Display Name</em>}</li>
 *   <li>{@link co.classLayout2Frontend.SiteView#getPageViews <em>Page Views</em>}</li>
 * </ul>
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getSiteView()
 * @model
 * @generated
 */
public interface SiteView extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getSiteView_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.SiteView#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Template Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Template Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Template Name</em>' attribute.
	 * @see #setTemplateName(String)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getSiteView_TemplateName()
	 * @model
	 * @generated
	 */
	String getTemplateName();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.SiteView#getTemplateName <em>Template Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Template Name</em>' attribute.
	 * @see #getTemplateName()
	 * @generated
	 */
	void setTemplateName(String value);

	/**
	 * Returns the value of the '<em><b>Template Color</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Template Color</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Template Color</em>' attribute.
	 * @see #setTemplateColor(String)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getSiteView_TemplateColor()
	 * @model
	 * @generated
	 */
	String getTemplateColor();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.SiteView#getTemplateColor <em>Template Color</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Template Color</em>' attribute.
	 * @see #getTemplateColor()
	 * @generated
	 */
	void setTemplateColor(String value);

	/**
	 * Returns the value of the '<em><b>Display Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Display Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Display Name</em>' attribute.
	 * @see #setDisplayName(String)
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getSiteView_DisplayName()
	 * @model
	 * @generated
	 */
	String getDisplayName();

	/**
	 * Sets the value of the '{@link co.classLayout2Frontend.SiteView#getDisplayName <em>Display Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Display Name</em>' attribute.
	 * @see #getDisplayName()
	 * @generated
	 */
	void setDisplayName(String value);

	/**
	 * Returns the value of the '<em><b>Page Views</b></em>' reference list.
	 * The list contents are of type {@link co.classLayout2Frontend.PageView}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Page Views</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Page Views</em>' reference list.
	 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getSiteView_PageViews()
	 * @model
	 * @generated
	 */
	EList<PageView> getPageViews();

} // SiteView
