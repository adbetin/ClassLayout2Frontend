/**
 */
package co.classLayout2Frontend;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Form</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getInputForm()
 * @model
 * @generated
 */
public interface InputForm extends ContainerView {
} // InputForm
