/**
 */
package co.classLayout2Frontend;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Layout Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see co.classLayout2Frontend.ClassLayout2FrontendPackage#getLayoutType()
 * @model
 * @generated
 */
public enum LayoutType implements Enumerator {
	/**
	 * The '<em><b>SINGLE COLUMN</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SINGLE_COLUMN_VALUE
	 * @generated
	 * @ordered
	 */
	SINGLE_COLUMN(0, "SINGLE_COLUMN", "SINGLE_COLUMN"),

	/**
	 * The '<em><b>TWO COLUMNS</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TWO_COLUMNS_VALUE
	 * @generated
	 * @ordered
	 */
	TWO_COLUMNS(1, "TWO_COLUMNS", "TWO_COLUMNS"),

	/**
	 * The '<em><b>LEFT BAR</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LEFT_BAR_VALUE
	 * @generated
	 * @ordered
	 */
	LEFT_BAR(2, "LEFT_BAR", "LEFT_BAR"),

	/**
	 * The '<em><b>RIGHT BAR</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RIGHT_BAR_VALUE
	 * @generated
	 * @ordered
	 */
	RIGHT_BAR(3, "RIGHT_BAR", "RIGHT_BAR"),

	/**
	 * The '<em><b>THREE COLUMNS</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #THREE_COLUMNS_VALUE
	 * @generated
	 * @ordered
	 */
	THREE_COLUMNS(4, "THREE_COLUMNS", "THREE_COLUMNS");

	/**
	 * The '<em><b>SINGLE COLUMN</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SINGLE COLUMN</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SINGLE_COLUMN
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SINGLE_COLUMN_VALUE = 0;

	/**
	 * The '<em><b>TWO COLUMNS</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>TWO COLUMNS</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TWO_COLUMNS
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int TWO_COLUMNS_VALUE = 1;

	/**
	 * The '<em><b>LEFT BAR</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>LEFT BAR</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #LEFT_BAR
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int LEFT_BAR_VALUE = 2;

	/**
	 * The '<em><b>RIGHT BAR</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RIGHT BAR</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RIGHT_BAR
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int RIGHT_BAR_VALUE = 3;

	/**
	 * The '<em><b>THREE COLUMNS</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>THREE COLUMNS</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #THREE_COLUMNS
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int THREE_COLUMNS_VALUE = 4;

	/**
	 * An array of all the '<em><b>Layout Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final LayoutType[] VALUES_ARRAY = new LayoutType[] { SINGLE_COLUMN, TWO_COLUMNS, LEFT_BAR, RIGHT_BAR,
			THREE_COLUMNS, };

	/**
	 * A public read-only list of all the '<em><b>Layout Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<LayoutType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Layout Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static LayoutType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			LayoutType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Layout Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static LayoutType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			LayoutType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Layout Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static LayoutType get(int value) {
		switch (value) {
		case SINGLE_COLUMN_VALUE:
			return SINGLE_COLUMN;
		case TWO_COLUMNS_VALUE:
			return TWO_COLUMNS;
		case LEFT_BAR_VALUE:
			return LEFT_BAR;
		case RIGHT_BAR_VALUE:
			return RIGHT_BAR;
		case THREE_COLUMNS_VALUE:
			return THREE_COLUMNS;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private LayoutType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //LayoutType
