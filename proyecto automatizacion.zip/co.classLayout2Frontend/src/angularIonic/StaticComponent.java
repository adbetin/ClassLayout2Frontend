/**
 */
package angularIonic;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Static Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see angularIonic.AngularIonicPackage#getStaticComponent()
 * @model
 * @generated
 */
public interface StaticComponent extends Component {
} // StaticComponent
