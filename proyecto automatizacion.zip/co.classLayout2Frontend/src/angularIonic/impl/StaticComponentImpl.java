/**
 */
package angularIonic.impl;

import angularIonic.AngularIonicPackage;
import angularIonic.StaticComponent;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Static Component</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StaticComponentImpl extends ComponentImpl implements StaticComponent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StaticComponentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AngularIonicPackage.Literals.STATIC_COMPONENT;
	}

} //StaticComponentImpl
