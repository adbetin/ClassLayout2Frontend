/**
 */
package angularIonic;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Form Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see angularIonic.AngularIonicPackage#getFormComponent()
 * @model
 * @generated
 */
public interface FormComponent extends Component {
} // FormComponent
